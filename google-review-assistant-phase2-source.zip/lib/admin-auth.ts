import { eq } from "drizzle-orm";
import { admins } from "@/db/schema";
import { getDb } from "@/db";
import { requireChatGPTUser } from "@/app/chatgpt-auth";

// Only the Sites project owner may bootstrap the first administrator.
const PLATFORM_OWNER_USER_ID = "REPLACE_WITH_SITE_OWNER_USER_ID";

export async function requireAdmin(returnTo = "/admin") {
  const user = await requireChatGPTUser(returnTo);
  const db = getDb();
  const existing = await db.select().from(admins).limit(1);
  if (existing.length === 0) {
    if (user.userId !== PLATFORM_OWNER_USER_ID) {
      throw new Error("ADMIN_ACCESS_DENIED");
    }
    await db.insert(admins).values({ id: crypto.randomUUID(), userId: user.userId, email: user.email, displayName: user.displayName, role: "owner" }).onConflictDoNothing();
  }
  const [admin] = await db.select().from(admins).where(eq(admins.userId, user.userId)).limit(1);
  if (!admin) throw new Error("ADMIN_ACCESS_DENIED");
  return { user, admin };
}
