"use client";

import { useEffect, useState } from "react";
import { ArrowRight, Check, Copy } from "lucide-react";

type Merchant = { name: string; slug: string; googleReviewLink: string; primaryColor: string; language: string; logoUrl: string | null };
export function ReviewAssistant({ merchant, templates }: { merchant: Merchant; templates: string[] }) {
  const [status, setStatus] = useState<"idle" | "working" | "copied" | "manual">("idle");
  const [review, setReview] = useState("");
  useEffect(() => { const key = `review-scan-${merchant.slug}`; if (!sessionStorage.getItem(key)) { sessionStorage.setItem(key, "1"); void record("scan"); } }, [merchant.slug]);
  async function record(type: string) { try { await fetch("/api/events", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ slug: merchant.slug, type }), keepalive: true }); } catch {} }
  function businessText(value: string) { return value.replaceAll("【商家名称】", merchant.name).replaceAll("【Business Name】", merchant.name).replaceAll("【Nama Perniagaan】", merchant.name); }
  async function generate() {
    if (status === "working" || !templates.length) return;
    setStatus("working"); const draft = businessText(templates[Math.floor(Math.random() * templates.length)]); setReview(draft); void record("generate");
    try { await navigator.clipboard.writeText(draft); setStatus("copied"); if (merchant.googleReviewLink) window.setTimeout(() => { void record("redirect"); window.location.assign(merchant.googleReviewLink); }, 1300); else setStatus("manual"); } catch { setStatus("manual"); }
  }
  const zh = merchant.language === "zh";
  return <main className="grid min-h-dvh place-items-center bg-[#f7f7f5] px-4 py-8"><section className="w-full max-w-[470px] rounded-[28px] border bg-white p-6 text-center shadow-[0_24px_80px_rgba(16,20,27,.10)] sm:p-9"><div className="mx-auto grid size-24 place-items-center overflow-hidden rounded-3xl bg-slate-100">{merchant.logoUrl ? <img src={merchant.logoUrl} alt={`${merchant.name} Logo`} className="size-full object-contain" /> : <span className="text-2xl font-black" style={{ color: merchant.primaryColor }}>{merchant.name.split(/\s+/).slice(0, 2).map((word) => word[0]).join("")}</span>}</div><p className="mt-7 text-xs font-black tracking-[.15em]" style={{ color: merchant.primaryColor }}>GOOGLE REVIEW ASSISTANT</p><h1 className="mt-3 text-3xl font-black tracking-tight sm:text-4xl">{merchant.name}</h1><p className="mx-auto mt-4 max-w-sm leading-7 text-slate-600">{zh ? "感谢您的支持！轻按下面的按钮，我们会帮您整理一段评价。" : "Thank you for your support. Tap below and we’ll help prepare a review draft."}</p><button onClick={generate} disabled={status === "working" || !templates.length} className="mt-7 flex min-h-15 w-full items-center justify-between rounded-2xl px-5 font-bold text-white shadow-lg disabled:opacity-60" style={{ backgroundColor: merchant.primaryColor }}><span>{status === "working" ? "正在整理评价…" : status === "copied" ? "评价已复制" : zh ? "生成评价并前往 Google" : "Generate review and open Google"}</span>{status === "copied" ? <Check /> : <ArrowRight />}</button>{review && <div className="mt-4 rounded-xl bg-slate-50 p-4 text-left text-sm leading-6"><div className="mb-2 flex items-center gap-2 font-semibold"><Copy className="size-4" />{status === "manual" ? "请长按并复制这段评价" : "评价草稿"}</div>{review}</div>}<p className="mt-5 text-xs leading-5 text-slate-500">{zh ? "系统生成的文字仅供参考，请根据您的真实体验修改，并自行选择适合的评分。" : "This draft is for reference only. Please edit it based on your genuine experience and choose your own rating."}</p><a href="https://ryankey.com.my/" target="_blank" rel="noreferrer" className="mt-7 inline-block text-xs text-slate-500 hover:underline">Powered by RyanKey Designs</a></section></main>;
}
