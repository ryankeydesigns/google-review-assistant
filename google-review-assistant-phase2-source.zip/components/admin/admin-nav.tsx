"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BarChart3, Building2, MessageSquareText, QrCode, Settings } from "lucide-react";

const items = [
  { href: "/admin", label: "总览", icon: BarChart3, exact: true },
  { href: "/admin/merchants", label: "所有商家", icon: Building2 },
  { href: "/admin/reviews", label: "评价资料", icon: MessageSquareText },
  { href: "/admin/qr-codes", label: "QR Codes", icon: QrCode },
  { href: "/admin/settings", label: "设置", icon: Settings },
];

export function AdminNav() {
  const pathname = usePathname();

  return <nav className="mt-8 grid grid-cols-2 gap-2 lg:grid-cols-1" aria-label="后台导航">
    {items.map((item) => {
      const active = item.exact ? pathname === item.href : pathname.startsWith(item.href);
      const Icon = item.icon;
      return <Link
        key={item.href}
        href={item.href}
        aria-current={active ? "page" : undefined}
        className={`flex min-h-11 items-center gap-3 rounded-xl px-3 py-3 text-sm transition-colors ${active ? "bg-sidebar-accent font-semibold text-white" : "text-slate-300 hover:bg-sidebar-accent hover:text-white"}`}
      >
        <Icon className="size-4 shrink-0" />
        <span>{item.label}</span>
      </Link>;
    })}
  </nav>;
}
