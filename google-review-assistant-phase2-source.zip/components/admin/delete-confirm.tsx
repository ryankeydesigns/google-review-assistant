"use client";

import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

export function DeleteConfirm({ action, fields, label = "删除", description }: { action: (formData: FormData) => void | Promise<void>; fields: Record<string, string>; label?: string; description: string }) {
  return <AlertDialog><AlertDialogTrigger asChild><Button type="button" variant="ghost" size="sm" className="text-destructive"><Trash2 />{label}</Button></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>确认永久删除？</AlertDialogTitle><AlertDialogDescription>{description}</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>取消</AlertDialogCancel><form action={action}>{Object.entries(fields).map(([name, value]) => <input key={name} type="hidden" name={name} value={value} />)}<AlertDialogAction asChild><Button type="submit" variant="destructive">永久删除</Button></AlertDialogAction></form></AlertDialogFooter></AlertDialogContent></AlertDialog>;
}
