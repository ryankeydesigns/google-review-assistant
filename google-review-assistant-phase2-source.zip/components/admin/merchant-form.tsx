import { Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ActiveSwitch, LanguageSelect } from "@/components/admin/form-controls";

type Merchant = { id: string; name: string; slug: string; industry: string; language: string; googleReviewLink: string; primaryColor: string; active: boolean };
export function MerchantForm({ merchant, action }: { merchant?: Merchant; action: (formData: FormData) => void | Promise<void> }) {
  const fieldClass = "grid content-start gap-2 self-start";
  return <form action={action} encType="multipart/form-data" className="grid gap-6">{merchant && <input type="hidden" name="id" value={merchant.id} />}<div className="grid items-start gap-x-5 gap-y-6 sm:grid-cols-2">
    <div className={fieldClass}><Label htmlFor="merchant-name">商家名称</Label><Input id="merchant-name" name="name" defaultValue={merchant?.name} required className="h-11 bg-white" placeholder="例如 ABC Coffee House" /></div>
    <div className={fieldClass}><Label htmlFor="merchant-slug">专属网址代号</Label><Input id="merchant-slug" name="slug" defaultValue={merchant?.slug} required pattern="[a-z0-9]+(?:-[a-z0-9]+)*" className="h-11 bg-white" placeholder="abc-coffee" /><p className="text-xs font-normal leading-4 text-muted-foreground">只可使用小写英文、数字及连字符</p></div>
    <div className={fieldClass}><Label htmlFor="merchant-industry">商家行业</Label><Input id="merchant-industry" name="industry" defaultValue={merchant?.industry} required className="h-11 bg-white" placeholder="餐厅、学院、美容院…" /></div>
    <div className={fieldClass}><Label htmlFor="merchant-language">评价语言</Label><LanguageSelect id="merchant-language" defaultValue={merchant?.language} /></div>
  </div><div className={fieldClass}><Label htmlFor="merchant-review-link">官方 Google Review Link</Label><Input id="merchant-review-link" name="googleReviewLink" type="url" defaultValue={merchant?.googleReviewLink} className="h-11 bg-white" placeholder="https://g.page/r/…/review" /></div><div className="grid items-start gap-x-5 gap-y-6 sm:grid-cols-2">
    <div className={fieldClass}><Label htmlFor="merchant-color">品牌颜色</Label><Input id="merchant-color" name="primaryColor" defaultValue={merchant?.primaryColor ?? "#2563EB"} pattern="#[0-9A-Fa-f]{6}" className="h-11 bg-white" /></div>
    <div className={fieldClass}><Label htmlFor="merchant-logo">商家 Logo</Label><Input id="merchant-logo" name="logo" type="file" accept="image/png,image/jpeg,image/webp" className="h-11 bg-white file:mr-3" /><p className="text-xs font-normal leading-4 text-muted-foreground">PNG、JPG或WebP，最大2MB</p></div>
  </div><div className="flex flex-wrap items-center justify-between gap-4 border-t pt-5"><ActiveSwitch defaultChecked={merchant?.active ?? true} /><Button type="submit" size="lg" className="rounded-xl"><Save />{merchant ? "保存商家资料" : "建立商家"}</Button></div></form>;
}
