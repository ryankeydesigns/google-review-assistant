"use client";

import { useState } from "react";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function ActiveSwitch({ defaultChecked = true }: { defaultChecked?: boolean }) {
  const [active, setActive] = useState(defaultChecked);
  return <div className="flex items-center gap-3"><Switch checked={active} onCheckedChange={setActive} aria-label="商家启用状态" /><input type="hidden" name="active" value={active ? "1" : "0"} /><span className="text-sm font-medium">{active ? "已启用" : "已暂停"}</span></div>;
}
export function LanguageSelect({ id, defaultValue = "zh" }: { id?: string; defaultValue?: string }) {
  const [value, setValue] = useState(defaultValue);
  return <><input type="hidden" name="language" value={value} /><Select value={value} onValueChange={(next) => next && setValue(next)}><SelectTrigger id={id} className="h-11 w-full bg-white"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="zh">中文</SelectItem><SelectItem value="en">English</SelectItem><SelectItem value="ms">Bahasa Melayu</SelectItem></SelectContent></Select></>;
}
