"use client";

import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { Download, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

export function QrCard({ slug, merchantName }: { slug: string; merchantName: string }) {
  const [url, setUrl] = useState(""); const [dataUrl, setDataUrl] = useState("");
  useEffect(() => { const merchantUrl = `${window.location.origin}/r/${slug}`; setUrl(merchantUrl); QRCode.toDataURL(merchantUrl, { width: 360, margin: 2, errorCorrectionLevel: "H", color: { dark: "#0E1726", light: "#FFFFFF" } }).then(setDataUrl); }, [slug]);
  return <div className="rounded-2xl border bg-card p-5 shadow-sm"><p className="text-xs font-bold tracking-[.14em] text-primary">MERCHANT QR</p><h2 className="mt-2 text-xl font-bold">专属 QR Code</h2>{dataUrl ? <img src={dataUrl} alt={`${merchantName} QR Code`} className="mx-auto my-5 size-52 rounded-xl" /> : <div className="mx-auto my-5 size-52 animate-pulse rounded-xl bg-muted" />}<p className="break-all text-xs text-muted-foreground">{url}</p><div className="mt-4 grid grid-cols-2 gap-2"><Button asChild variant="outline"><a href={url} target="_blank" rel="noreferrer"><ExternalLink />预览</a></Button><Button asChild><a href={dataUrl} download={`${slug}-qr-code.png`}><Download />下载</a></Button></div></div>;
}
