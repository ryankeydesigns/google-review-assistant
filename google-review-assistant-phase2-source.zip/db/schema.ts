import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

export const admins = sqliteTable("admins", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  email: text("email").notNull(),
  displayName: text("display_name").notNull(),
  role: text("role").notNull().default("owner"),
  createdAt: integer("created_at").notNull().default(sql`(unixepoch())`),
});

export const merchants = sqliteTable("merchants", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  industry: text("industry").notNull(),
  language: text("language").notNull().default("zh"),
  googleReviewLink: text("google_review_link").notNull().default(""),
  logoKey: text("logo_key"),
  primaryColor: text("primary_color").notNull().default("#2563EB"),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: integer("created_at").notNull().default(sql`(unixepoch())`),
  updatedAt: integer("updated_at").notNull().default(sql`(unixepoch())`),
}, (table) => [
  uniqueIndex("idx_merchants_slug").on(table.slug),
  index("idx_merchants_active").on(table.active),
]);

export const reviewTemplates = sqliteTable("review_templates", {
  id: text("id").primaryKey(),
  merchantId: text("merchant_id").notNull().references(() => merchants.id, { onDelete: "cascade" }),
  language: text("language").notNull().default("zh"),
  content: text("content").notNull(),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: integer("created_at").notNull().default(sql`(unixepoch())`),
}, (table) => [index("idx_review_templates_merchant_active").on(table.merchantId, table.active)]);

export const events = sqliteTable("events", {
  id: text("id").primaryKey(),
  merchantId: text("merchant_id").notNull().references(() => merchants.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  createdAt: integer("created_at").notNull().default(sql`(unixepoch())`),
}, (table) => [
  index("idx_events_merchant_type").on(table.merchantId, table.type),
  index("idx_events_created_at").on(table.createdAt),
]);
