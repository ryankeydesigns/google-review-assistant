import { and, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { events, merchants } from "@/db/schema";

export async function POST(request: Request) {
  let body: { slug?: string; type?: string };
  try { body = await request.json(); } catch { return Response.json({ ok: false }, { status: 400 }); }
  if (!body.slug || !new Set(["scan", "generate", "redirect"]).has(body.type ?? "")) return Response.json({ ok: false }, { status: 400 });
  const db = getDb();
  const [merchant] = await db.select({ id: merchants.id }).from(merchants).where(and(eq(merchants.slug, body.slug), eq(merchants.active, true))).limit(1);
  if (!merchant) return Response.json({ ok: false }, { status: 404 });
  await db.insert(events).values({ id: crypto.randomUUID(), merchantId: merchant.id, type: body.type! });
  return Response.json({ ok: true });
}
