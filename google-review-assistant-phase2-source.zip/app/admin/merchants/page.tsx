import Link from "next/link";
import { desc } from "drizzle-orm";
import { ExternalLink, Plus, Store } from "lucide-react";
import { getDb } from "@/db";
import { merchants } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { deleteMerchant } from "@/app/admin/actions";
import { DeleteConfirm } from "@/components/admin/delete-confirm";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const dynamic = "force-dynamic";

export default async function MerchantsPage() {
  await requireAdmin("/admin/merchants");
  const rows = await getDb().select().from(merchants).orderBy(desc(merchants.createdAt));

  return <div className="mx-auto max-w-7xl">
    <header className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
      <div><p className="text-xs font-black tracking-[.16em] text-primary">MERCHANT DIRECTORY</p><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">所有商家</h1><p className="mt-2 text-muted-foreground">集中管理商家资料、启用状态及顾客评价入口。</p></div>
      <Button asChild size="lg" className="rounded-xl"><Link href="/admin/merchants/new"><Plus />新增商家</Link></Button>
    </header>
    <section className="mt-8 overflow-hidden rounded-2xl border bg-card shadow-sm">
      {rows.length ? <Table><TableHeader><TableRow><TableHead className="pl-5">商家</TableHead><TableHead>行业</TableHead><TableHead>语言</TableHead><TableHead>状态</TableHead><TableHead className="pr-5 text-right">操作</TableHead></TableRow></TableHeader><TableBody>{rows.map((merchant) => <TableRow key={merchant.id}><TableCell className="pl-5"><div className="font-semibold">{merchant.name}</div><div className="text-xs text-muted-foreground">/r/{merchant.slug}</div></TableCell><TableCell>{merchant.industry}</TableCell><TableCell>{merchant.language === "zh" ? "中文" : merchant.language === "ms" ? "Bahasa Melayu" : "English"}</TableCell><TableCell><Badge variant={merchant.active ? "default" : "outline"}>{merchant.active ? "已启用" : "已暂停"}</Badge></TableCell><TableCell className="pr-5"><div className="flex justify-end gap-1"><Button asChild variant="ghost" size="sm"><Link href={`/r/${merchant.slug}`} target="_blank"><ExternalLink />预览</Link></Button><Button asChild variant="outline" size="sm"><Link href={`/admin/merchants/${merchant.id}/edit`}>管理</Link></Button><DeleteConfirm action={deleteMerchant} fields={{ id: merchant.id }} description={`删除 ${merchant.name} 后，所有评价模板及统计数据都会永久删除。`} /></div></TableCell></TableRow>)}</TableBody></Table> : <div className="grid place-items-center px-5 py-16 text-center"><span className="grid size-14 place-items-center rounded-2xl bg-muted text-muted-foreground"><Store /></span><h2 className="mt-4 text-lg font-bold">还没有商家</h2><Button asChild className="mt-5"><Link href="/admin/merchants/new"><Plus />新增商家</Link></Button></div>}
    </section>
  </div>;
}
