import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { requireAdmin } from "@/lib/admin-auth";
import { createMerchant } from "@/app/admin/actions";
import { MerchantForm } from "@/components/admin/merchant-form";
import { Button } from "@/components/ui/button";

export const dynamic = "force-dynamic";
export default async function NewMerchantPage() {
  await requireAdmin("/admin/merchants/new");
  return <div className="mx-auto max-w-4xl"><Button asChild variant="ghost" className="-ml-3"><Link href="/admin"><ArrowLeft />返回管理中心</Link></Button><div className="mt-5 rounded-2xl border bg-card p-6 shadow-sm sm:p-8"><p className="text-xs font-black tracking-[.16em] text-primary">NEW MERCHANT</p><h1 className="mt-2 text-3xl font-black tracking-tight">新增商家</h1><p className="mt-2 text-muted-foreground">建立商家后，系统会自动加入五段评价模板并生成专属 QR Code。</p><div className="mt-8"><MerchantForm action={createMerchant} /></div></div></div>;
}
