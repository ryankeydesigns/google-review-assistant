import Link from "next/link";
import { count, eq } from "drizzle-orm";
import { ArrowLeft, MessageSquareText } from "lucide-react";
import { getDb } from "@/db";
import { events, merchants, reviewTemplates } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { addTemplate, deleteTemplate, updateMerchant } from "@/app/admin/actions";
import { MerchantForm } from "@/components/admin/merchant-form";
import { QrCard } from "@/components/admin/qr-card";
import { DeleteConfirm } from "@/components/admin/delete-confirm";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export const dynamic = "force-dynamic";
const statLabel: Record<string, string> = { scan: "扫描", generate: "生成", redirect: "跳转" };
export default async function EditMerchantPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ created?: string; saved?: string }> }) {
  const { id } = await params; const query = await searchParams;
  await requireAdmin(`/admin/merchants/${id}/edit`);
  const db = getDb();
  const [merchantRows, templates, stats] = await Promise.all([
    db.select().from(merchants).where(eq(merchants.id, id)).limit(1),
    db.select().from(reviewTemplates).where(eq(reviewTemplates.merchantId, id)),
    db.select({ type: events.type, total: count() }).from(events).where(eq(events.merchantId, id)).groupBy(events.type),
  ]);
  const merchant = merchantRows[0];
  if (!merchant) return <div className="rounded-2xl border bg-card p-8"><h1 className="text-2xl font-black">找不到商家</h1><Button asChild className="mt-5"><Link href="/admin">返回</Link></Button></div>;
  return <div className="mx-auto max-w-7xl"><Button asChild variant="ghost" className="-ml-3"><Link href="/admin"><ArrowLeft />返回管理中心</Link></Button>{(query.created || query.saved) && <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800">{query.created ? "商家已经建立，评价模板及 QR Code 已准备完成。" : "商家资料已保存。"}</div>}<header className="mt-5"><p className="text-xs font-black tracking-[.16em] text-primary">MERCHANT CONTROL</p><h1 className="mt-2 text-3xl font-black tracking-tight">{merchant.name}</h1><p className="mt-2 text-muted-foreground">管理品牌资料、评价内容和顾客入口。</p></header><div className="mt-7 grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]"><div className="grid gap-6"><section className="rounded-2xl border bg-card p-6 shadow-sm sm:p-8"><h2 className="text-xl font-bold">商家资料</h2><div className="mt-6"><MerchantForm merchant={merchant} action={updateMerchant} /></div></section><section className="rounded-2xl border bg-card p-6 shadow-sm sm:p-8"><div className="flex items-start justify-between"><div><h2 className="text-xl font-bold">评价资料库</h2><p className="mt-1 text-sm text-muted-foreground">顾客每次按下按钮，系统会随机选择一段启用中的评价。</p></div><span className="grid size-10 place-items-center rounded-xl bg-primary/10 text-primary"><MessageSquareText className="size-5" /></span></div><form action={addTemplate} className="mt-6 grid gap-3"><input type="hidden" name="merchantId" value={merchant.id} /><input type="hidden" name="language" value={merchant.language} /><Textarea name="content" required maxLength={500} placeholder="输入新的评价模板，可加入【商家名称】占位文字。" className="min-h-24 bg-white" /><Button type="submit" className="justify-self-end">添加评价模板</Button></form><div className="mt-6 grid gap-3">{templates.map((template) => <div key={template.id} className="flex items-start gap-3 rounded-xl border bg-muted/35 p-4"><p className="flex-1 text-sm leading-6">{template.content}</p><DeleteConfirm action={deleteTemplate} fields={{ id: template.id, merchantId: merchant.id }} label="" description="这段评价模板会被永久删除。" /></div>)}</div></section></div><aside className="grid content-start gap-5"><QrCard slug={merchant.slug} merchantName={merchant.name} /><div className="rounded-2xl bg-sidebar p-5 text-white"><p className="text-xs font-bold tracking-[.14em] text-blue-300">LIVE DATA</p><h2 className="mt-2 text-xl font-bold">互动统计</h2><div className="mt-5 grid grid-cols-3 gap-2">{["scan", "generate", "redirect"].map((type) => <div key={type} className="rounded-xl bg-white/8 p-3 text-center"><p className="text-2xl font-black">{stats.find((item) => item.type === type)?.total ?? 0}</p><p className="mt-1 text-[11px] text-slate-400">{statLabel[type]}</p></div>)}</div></div></aside></div></div>;
}
