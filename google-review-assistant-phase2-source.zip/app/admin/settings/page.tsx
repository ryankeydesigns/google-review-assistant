import { CheckCircle2, Database, LockKeyhole } from "lucide-react";
import { requireAdmin } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const { user } = await requireAdmin("/admin/settings");
  const items = [
    { icon: LockKeyhole, title: "管理员权限", value: user.email, note: "只有网站拥有者可以进入管理后台。" },
    { icon: Database, title: "资料储存", value: "Cloud Database", note: "商家、评价模板及统计数据集中储存。" },
    { icon: CheckCircle2, title: "公开测试", value: "已启用", note: "顾客可通过商家专属网址及 QR Code 进入评价页。" },
  ];
  return <div className="mx-auto max-w-4xl"><header><p className="text-xs font-black tracking-[.16em] text-primary">PLATFORM SETTINGS</p><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">设置</h1><p className="mt-2 text-muted-foreground">查看平台权限、资料储存及公开测试状态。</p></header><section className="mt-8 grid gap-4">{items.map((item) => <article key={item.title} className="grid gap-4 rounded-2xl border bg-card p-5 shadow-sm sm:grid-cols-[44px_1fr_auto] sm:items-center"><span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary"><item.icon className="size-5" /></span><div><h2 className="font-bold">{item.title}</h2><p className="mt-1 text-sm text-muted-foreground">{item.note}</p></div><strong className="break-all text-sm sm:text-right">{item.value}</strong></article>)}</section></div>;
}
