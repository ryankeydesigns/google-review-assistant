import Link from "next/link";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { AdminNav } from "@/components/admin/admin-nav";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await getChatGPTUser();
  return <div className="min-h-screen bg-background text-foreground lg:grid lg:grid-cols-[248px_1fr]">
    <aside className="bg-sidebar px-5 py-6 text-sidebar-foreground lg:sticky lg:top-0 lg:h-screen">
      <Link href="/admin" className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-sidebar-primary font-black">R</span><span><strong className="block text-sm">REVIEW CONTROL</strong><span className="text-xs text-slate-400">RyanKey Designs</span></span></Link>
      <AdminNav />
      <div className="mt-8 border-t border-sidebar-border pt-5 lg:absolute lg:inset-x-5 lg:bottom-6"><p className="truncate text-sm font-medium">{user?.displayName ?? "管理员"}</p><p className="truncate text-xs text-slate-400">{user?.email ?? "请登录 ChatGPT"}</p></div>
    </aside>
    <main className="admin-grid-bg min-w-0 p-5 sm:p-8 lg:p-10">{children}</main>
  </div>;
}
