import Link from "next/link";
import { count, desc } from "drizzle-orm";
import { ArrowUpRight, Building2, ExternalLink, MousePointerClick, Plus, QrCode, ScanLine } from "lucide-react";
import { getDb } from "@/db";
import { events, merchants } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DeleteConfirm } from "@/components/admin/delete-confirm";
import { deleteMerchant } from "@/app/admin/actions";

export const dynamic = "force-dynamic";
export default async function AdminDashboard() {
  const { user } = await requireAdmin("/admin");
  const db = getDb();
  const [merchantRows, eventRows] = await Promise.all([
    db.select().from(merchants).orderBy(desc(merchants.createdAt)),
    db.select({ merchantId: events.merchantId, type: events.type, total: count() }).from(events).groupBy(events.merchantId, events.type),
  ]);
  const totals = { scan: 0, generate: 0, redirect: 0 };
  const byMerchant: Record<string, { scan: number; generate: number; redirect: number }> = {};
  eventRows.forEach((row) => { if (!(row.type in totals)) return; const type = row.type as keyof typeof totals; totals[type] += row.total; byMerchant[row.merchantId] ??= { scan: 0, generate: 0, redirect: 0 }; byMerchant[row.merchantId][type] += row.total; });
  const cards = [
    { label: "所有商家", value: merchantRows.length, note: `${merchantRows.filter((m) => m.active).length} 个已启用`, icon: Building2 },
    { label: "QR 扫描", value: totals.scan, note: "评价页开启次数", icon: ScanLine },
    { label: "评价生成", value: totals.generate, note: "按钮点击次数", icon: MousePointerClick },
    { label: "Google 跳转", value: totals.redirect, note: "前往评论页面", icon: ArrowUpRight },
  ];
  return <div className="mx-auto max-w-7xl"><header className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-xs font-black tracking-[.16em] text-primary">RYANKEY ADMIN / PHASE 02</p><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">Google Review 管理中心</h1><p className="mt-2 text-muted-foreground">欢迎回来，{user.displayName}。所有商家资料和互动数据都在这里。</p></div><Button asChild size="lg" className="rounded-xl"><Link href="/admin/merchants/new"><Plus />新增商家</Link></Button></header>
    <section className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{cards.map((card) => <Card key={card.label} className="overflow-hidden border-0 shadow-sm"><CardContent className="p-5"><div className="flex items-start justify-between"><div><p className="text-sm font-semibold text-muted-foreground">{card.label}</p><p className="mt-3 text-4xl font-black tracking-tight">{card.value.toLocaleString()}</p></div><span className="grid size-10 place-items-center rounded-xl bg-primary/10 text-primary"><card.icon className="size-5" /></span></div><p className="mt-5 border-t pt-3 text-xs text-muted-foreground">{card.note}</p></CardContent></Card>)}</section>
    <section className="mt-8 overflow-hidden rounded-2xl border bg-card shadow-sm"><div className="flex items-center justify-between border-b px-5 py-4"><div><h2 className="font-bold">所有商家</h2><p className="text-sm text-muted-foreground">管理商家资料、评价模板与 QR Code</p></div><Badge variant="secondary">{merchantRows.length} MERCHANTS</Badge></div>{merchantRows.length ? <Table><TableHeader><TableRow><TableHead className="pl-5">商家</TableHead><TableHead>状态</TableHead><TableHead>扫描</TableHead><TableHead>生成</TableHead><TableHead>跳转</TableHead><TableHead className="pr-5 text-right">操作</TableHead></TableRow></TableHeader><TableBody>{merchantRows.map((merchant) => { const stats = byMerchant[merchant.id] ?? { scan: 0, generate: 0, redirect: 0 }; return <TableRow key={merchant.id}><TableCell className="pl-5"><div className="font-semibold">{merchant.name}</div><div className="text-xs text-muted-foreground">/r/{merchant.slug} · {merchant.industry}</div></TableCell><TableCell><Badge variant={merchant.active ? "default" : "outline"}>{merchant.active ? "已启用" : "已暂停"}</Badge></TableCell><TableCell>{stats.scan}</TableCell><TableCell>{stats.generate}</TableCell><TableCell>{stats.redirect}</TableCell><TableCell className="pr-5"><div className="flex justify-end gap-1"><Button asChild variant="ghost" size="sm"><Link href={`/r/${merchant.slug}`} target="_blank"><ExternalLink />预览</Link></Button><Button asChild variant="outline" size="sm"><Link href={`/admin/merchants/${merchant.id}/edit`}>管理</Link></Button><DeleteConfirm action={deleteMerchant} fields={{ id: merchant.id }} description={`删除 ${merchant.name} 后，所有评价模板及统计数据都会永久删除。`} /></div></TableCell></TableRow>; })}</TableBody></Table> : <div className="grid place-items-center px-5 py-16 text-center"><span className="grid size-14 place-items-center rounded-2xl bg-muted text-muted-foreground"><QrCode /></span><h3 className="mt-4 text-lg font-bold">还没有商家</h3><p className="mt-1 text-sm text-muted-foreground">建立第一个商家后，系统会自动准备评价模板及专属 QR Code。</p><Button asChild className="mt-5"><Link href="/admin/merchants/new"><Plus />新增商家</Link></Button></div>}</section>
  </div>;
}
