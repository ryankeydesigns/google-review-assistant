"use server";

import { env } from "cloudflare:workers";
import { and, eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getDb } from "@/db";
import { events, merchants, reviewTemplates } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";

const DEFAULT_TEMPLATES: Record<string, string[]> = {
  zh: [
    "这次在【商家名称】的体验很好，工作人员亲切专业，整个过程顺利，值得推荐。",
    "【商家名称】的团队很有耐心，服务细心，整体体验令人满意。",
    "第一次来到【商家名称】，环境舒适，服务也比预期更好，下次还会再来。",
    "感谢【商家名称】工作人员的协助，沟通清楚，让人感觉很放心。",
    "整体体验很好，工作人员友善又专业，有需要会再次选择【商家名称】。",
  ],
  en: [
    "I had a pleasant experience with 【Business Name】. The team was friendly, helpful and professional.",
    "Great service from 【Business Name】. Everything was handled smoothly and the overall experience was satisfying.",
    "The staff at 【Business Name】 were patient and professional. I would be happy to visit again.",
    "My visit to 【Business Name】 was comfortable and well organised. Thank you for the thoughtful service.",
    "【Business Name】 provided a smooth and positive experience. I would gladly recommend the team.",
  ],
  ms: [
    "Pengalaman saya di 【Nama Perniagaan】 sangat baik. Kakitangan mesra, membantu dan profesional.",
    "Perkhidmatan di 【Nama Perniagaan】 berjalan lancar dan keseluruhan pengalaman sangat memuaskan.",
    "Kakitangan 【Nama Perniagaan】 sabar dan profesional. Saya berbesar hati untuk datang lagi.",
    "Saya berpuas hati dengan layanan di 【Nama Perniagaan】. Semuanya diurus dengan teliti.",
    "Pengalaman di 【Nama Perniagaan】 selesa dan menyenangkan. Terima kasih kepada seluruh pasukan.",
  ],
};

function textValue(formData: FormData, name: string) { return String(formData.get(name) ?? "").trim(); }
function merchantValues(formData: FormData) {
  const name = textValue(formData, "name");
  const slug = textValue(formData, "slug").toLowerCase();
  const industry = textValue(formData, "industry");
  const language = textValue(formData, "language");
  const googleReviewLink = textValue(formData, "googleReviewLink");
  const primaryColor = textValue(formData, "primaryColor") || "#2563EB";
  const active = textValue(formData, "active") === "1";
  if (!name || !industry || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) throw new Error("INVALID_MERCHANT_DATA");
  if (!new Set(["zh", "en", "ms"]).has(language)) throw new Error("INVALID_LANGUAGE");
  if (googleReviewLink && !googleReviewLink.startsWith("https://")) throw new Error("INVALID_REVIEW_LINK");
  if (!/^#[0-9A-Fa-f]{6}$/.test(primaryColor)) throw new Error("INVALID_COLOR");
  return { name, slug, industry, language, googleReviewLink, primaryColor, active };
}

async function uploadLogo(formData: FormData, merchantId: string) {
  const file = formData.get("logo");
  if (!(file instanceof File) || file.size === 0) return null;
  if (file.size > 2 * 1024 * 1024) throw new Error("LOGO_TOO_LARGE");
  const allowed: Record<string, string> = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp" };
  const extension = allowed[file.type];
  if (!extension) throw new Error("INVALID_LOGO_TYPE");
  if (!env.BUCKET) throw new Error("R2_UNAVAILABLE");
  const key = `merchant-logos/${merchantId}-${Date.now()}.${extension}`;
  await env.BUCKET.put(key, await file.arrayBuffer(), { httpMetadata: { contentType: file.type } });
  return key;
}

export async function createMerchant(formData: FormData) {
  await requireAdmin("/admin/merchants/new");
  const db = getDb();
  const values = merchantValues(formData);
  const id = crypto.randomUUID();
  const logoKey = await uploadLogo(formData, id);
  await db.insert(merchants).values({ id, ...values, logoKey });
  await db.insert(reviewTemplates).values((DEFAULT_TEMPLATES[values.language] ?? DEFAULT_TEMPLATES.zh).map((content) => ({ id: crypto.randomUUID(), merchantId: id, language: values.language, content, active: true })));
  revalidatePath("/admin");
  redirect(`/admin/merchants/${id}/edit?created=1`);
}

export async function updateMerchant(formData: FormData) {
  await requireAdmin("/admin");
  const db = getDb();
  const id = textValue(formData, "id");
  const values = merchantValues(formData);
  const logoKey = await uploadLogo(formData, id);
  const update: Record<string, unknown> = { ...values, updatedAt: sql`unixepoch()` };
  if (logoKey) update.logoKey = logoKey;
  await db.update(merchants).set(update).where(eq(merchants.id, id));
  revalidatePath("/admin");
  revalidatePath(`/admin/merchants/${id}/edit`);
  revalidatePath(`/r/${values.slug}`);
  redirect(`/admin/merchants/${id}/edit?saved=1`);
}

export async function deleteMerchant(formData: FormData) {
  await requireAdmin("/admin");
  const id = textValue(formData, "id");
  const db = getDb();
  await db.delete(events).where(eq(events.merchantId, id));
  await db.delete(reviewTemplates).where(eq(reviewTemplates.merchantId, id));
  await db.delete(merchants).where(eq(merchants.id, id));
  revalidatePath("/admin");
}

export async function addTemplate(formData: FormData) {
  await requireAdmin("/admin");
  const merchantId = textValue(formData, "merchantId");
  const language = textValue(formData, "language");
  const content = textValue(formData, "content");
  if (!merchantId || !content || content.length > 500) throw new Error("INVALID_TEMPLATE");
  const db = getDb();
  const [merchant] = await db.select().from(merchants).where(eq(merchants.id, merchantId)).limit(1);
  if (!merchant) throw new Error("MERCHANT_NOT_FOUND");
  await db.insert(reviewTemplates).values({ id: crypto.randomUUID(), merchantId, language, content, active: true });
  revalidatePath(`/admin/merchants/${merchantId}/edit`);
}

export async function deleteTemplate(formData: FormData) {
  await requireAdmin("/admin");
  const id = textValue(formData, "id");
  const merchantId = textValue(formData, "merchantId");
  const db = getDb();
  await db.delete(reviewTemplates).where(and(eq(reviewTemplates.id, id), eq(reviewTemplates.merchantId, merchantId)));
  revalidatePath(`/admin/merchants/${merchantId}/edit`);
}
