import Link from "next/link";
import { count, desc } from "drizzle-orm";
import { MessageSquareText } from "lucide-react";
import { getDb } from "@/db";
import { merchants, reviewTemplates } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const dynamic = "force-dynamic";

export default async function ReviewsPage() {
  await requireAdmin("/admin/reviews");
  const db = getDb();
  const [merchantRows, counts] = await Promise.all([
    db.select().from(merchants).orderBy(desc(merchants.createdAt)),
    db.select({ merchantId: reviewTemplates.merchantId, total: count() }).from(reviewTemplates).groupBy(reviewTemplates.merchantId),
  ]);
  const totals = Object.fromEntries(counts.map((item) => [item.merchantId, item.total]));

  return <div className="mx-auto max-w-5xl"><header><p className="text-xs font-black tracking-[.16em] text-primary">REVIEW LIBRARY</p><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">评价资料</h1><p className="mt-2 text-muted-foreground">查看每个商家的评价模板数量，并进入商家页面修改内容。</p></header><section className="mt-8 grid gap-4">{merchantRows.length ? merchantRows.map((merchant) => <article key={merchant.id} className="flex flex-col gap-4 rounded-2xl border bg-card p-5 shadow-sm sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-4"><span className="grid size-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><MessageSquareText className="size-5" /></span><div><h2 className="font-bold">{merchant.name}</h2><p className="text-sm text-muted-foreground">{merchant.language === "zh" ? "中文" : merchant.language === "ms" ? "Bahasa Melayu" : "English"}评价资料库</p></div></div><div className="flex items-center gap-3"><Badge variant="secondary">{totals[merchant.id] ?? 0} 段评价</Badge><Button asChild variant="outline"><Link href={`/admin/merchants/${merchant.id}/edit`}>管理评价</Link></Button></div></article>) : <div className="rounded-2xl border bg-card p-10 text-center text-muted-foreground">建立商家后，评价资料会显示在这里。</div>}</section></div>;
}
