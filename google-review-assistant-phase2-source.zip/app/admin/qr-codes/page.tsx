import Link from "next/link";
import { desc } from "drizzle-orm";
import { Plus } from "lucide-react";
import { getDb } from "@/db";
import { merchants } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { QrCard } from "@/components/admin/qr-card";
import { Button } from "@/components/ui/button";

export const dynamic = "force-dynamic";

export default async function QrCodesPage() {
  await requireAdmin("/admin/qr-codes");
  const rows = await getDb().select().from(merchants).orderBy(desc(merchants.createdAt));

  return <div className="mx-auto max-w-7xl"><header><p className="text-xs font-black tracking-[.16em] text-primary">QR DIRECTORY</p><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">QR Codes</h1><p className="mt-2 text-muted-foreground">预览或下载每个商家的专属顾客入口。</p></header>{rows.length ? <section className="mt-8 grid gap-5 md:grid-cols-2 xl:grid-cols-3">{rows.map((merchant) => <QrCard key={merchant.id} slug={merchant.slug} merchantName={merchant.name} />)}</section> : <section className="mt-8 rounded-2xl border bg-card p-10 text-center"><p className="text-muted-foreground">建立商家后，QR Code 会自动显示在这里。</p><Button asChild className="mt-5"><Link href="/admin/merchants/new"><Plus />新增商家</Link></Button></section>}</div>;
}
