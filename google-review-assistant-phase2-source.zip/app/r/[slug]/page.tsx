import { and, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { merchants, reviewTemplates } from "@/db/schema";
import { ReviewAssistant } from "@/components/public/review-assistant";

export const dynamic = "force-dynamic";
export default async function MerchantReviewPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params; const db = getDb();
  const [merchant] = await db.select().from(merchants).where(and(eq(merchants.slug, slug), eq(merchants.active, true))).limit(1);
  if (!merchant) return <main className="grid min-h-dvh place-items-center bg-[#f7f7f5] p-6 text-center"><div><p className="text-sm font-bold text-primary">GOOGLE REVIEW ASSISTANT</p><h1 className="mt-3 text-3xl font-black">此商家页面暂时不可用</h1><p className="mt-3 text-muted-foreground">请向商家确认最新的 QR Code 或网址。</p></div></main>;
  const templates = await db.select({ content: reviewTemplates.content }).from(reviewTemplates).where(and(eq(reviewTemplates.merchantId, merchant.id), eq(reviewTemplates.active, true)));
  return <ReviewAssistant merchant={{ name: merchant.name, slug: merchant.slug, googleReviewLink: merchant.googleReviewLink, primaryColor: merchant.primaryColor, language: merchant.language, logoUrl: merchant.logoKey ? `/media/${merchant.logoKey}` : null }} templates={templates.map((item) => item.content)} />;
}
