import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Google Review Assistant｜RyanKey Designs",
  description: "多商家 Google Review 文案与 QR Code 管理平台。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-Hans">
      <body className="antialiased">{children}</body>
    </html>
  );
}
