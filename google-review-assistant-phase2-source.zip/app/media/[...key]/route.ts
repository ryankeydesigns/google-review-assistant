import { env } from "cloudflare:workers";

export async function GET(_request: Request, { params }: { params: Promise<{ key: string[] }> }) {
  const { key } = await params; const objectKey = key.join("/");
  if (!/^merchant-logos\/[a-zA-Z0-9._-]+$/.test(objectKey) || !env.BUCKET) return new Response("Not found", { status: 404 });
  const object = await env.BUCKET.get(objectKey);
  if (!object) return new Response("Not found", { status: 404 });
  const headers = new Headers(); object.writeHttpMetadata(headers); headers.set("cache-control", "public, max-age=86400"); headers.set("x-content-type-options", "nosniff");
  return new Response(object.body, { headers });
}
